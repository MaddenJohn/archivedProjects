//
//  ViewController.swift
//  MaddenJonathan-hw9
//
//  Created by John Madden on 4/17/17.
//  Copyright © 2017 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

