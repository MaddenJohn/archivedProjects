//
//  ViewController.swift
//  MaddenJonathan-hw5
//
//  Created by John Madden on 2/22/17.
//  Copyright © 2017 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Candidate Manager"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
