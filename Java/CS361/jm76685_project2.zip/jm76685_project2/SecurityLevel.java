// Class to represent the security levels.
public class SecurityLevel {

	public static final int LOW = 0;
	public static final int HIGH = 1;
}

