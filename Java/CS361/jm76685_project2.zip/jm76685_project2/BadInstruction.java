/*
 * Class to return a specific string for when instructions are invalid.
 */
public class BadInstruction {
	public static String BadInstruction = "Bad Instruction";
}