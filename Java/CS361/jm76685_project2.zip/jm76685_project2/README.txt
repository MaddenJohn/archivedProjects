UTEID: jm76685;
FIRSTNAME: Jonathan;
LASTNAME: Madden;
CSACCOUNT: jm76685;
EMAIL: jm76685@cs.utexas.edu;

[Program 2]
[Description]
There are a total of 9 java files. Only CovertChannel.java, ReferenceMonitor.java, and InstructionObject.java were modified for this project,
and the remaining 6 follow the same principle as project 1. In CovertChannel.java the main part of this project was completed, which involved
the creation of the subjects, the extraction of the arguments, the reading of the file, the sending of bits from the high level subject and
low level subject over the covert channel, and the final output of the resulting file. ReferenceMonitor.java has all of the previous functions,
but also had functions to execute create, destroy, and run commands. This also required the InstructionObject to validate these commands, and
parse the arguments passed into these. 

[Machine Information]
MacBook Pro, 2.7 GHz Intel Core i5, 8 GB 1867 MHz DDR3

[Source Description]
I received the first test file from a Wikipedia article about vanity height, URL: https://en.wikipedia.org/wiki/Vanity_height.
This test file has a brief description of what this is and of the tallest buildings. 
I received the second test file from a Wikipedia article about Philip Boit, URL: https://en.wikipedia.org/wiki/Philip_Boit.
This test file has a brief description of his accomplishments and Olympic career. 

[Finish]
I finished all of the project. I did not do any of the extra credit.

[Results Summary]
[No.]  	[DocumentName]  		[Size]   		[Bandwidth]
1		Pride and Prejudice		688411 bytes 	1855 bits/ms
2		Metamorphosis			139054 bytes	1045 bits/ms
3		Test1					500 bytes 		111 bits/ms
4		Test2					472 bytes 		138 bits/ms


