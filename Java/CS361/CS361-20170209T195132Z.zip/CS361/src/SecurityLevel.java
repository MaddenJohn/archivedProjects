public class SecurityLevel {

	public static SecurityLevel LOW;
	public static SecurityLevel HIGH;
}

