// maintains labels, prevent any changes to labels
// checks BLP properties, if legal tells ObjectManager to perform
// always returns an integer value to the subject: the value of the 
// object read, if the command was a legal READ; and 0 otherwise
public class ReferenceMonitor {

}