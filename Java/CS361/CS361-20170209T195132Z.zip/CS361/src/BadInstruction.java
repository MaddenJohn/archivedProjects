public class BadInstruction {
	public static String BadInstruction = "Bad Instruction";
}