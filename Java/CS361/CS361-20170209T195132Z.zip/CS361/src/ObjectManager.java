// objects managed by this
public class ObjectManager {

}
