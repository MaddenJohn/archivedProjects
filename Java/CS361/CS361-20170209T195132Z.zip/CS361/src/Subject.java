/*public class Subject {
	String name;
	int TEMP;
	SecurityLevel label;
	public Subject (String n, SecurityLevel label){
		name = n;
		TEMP = 0;
		this.label = label;
	}

	public void setVal (int newVal){
		TEMP = newVal;
	}

	public int getVal() {
		return TEMP;
	}
}*/